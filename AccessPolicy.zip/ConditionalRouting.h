#ifndef CONDITIONAL_ROUTING_H
#define CONDITIONAL_ROUTING_H

#include "RoutingStrategy.h"
#include "Condition.h"
#include <vector>
#include <utility>
#include <string>

class ConditionalRouting : public RoutingStrategy {
private:
    std::vector<std::pair<Condition, std::string> > branches_;
public:
    std::vector<WorkNode*> nextNodes(WorkNode& done, WorkContainer& container,
                                     const WorkflowData& data) override;
    bool isComplete(const WorkContainer& container) const override;
};

#endif // CONDITIONAL_ROUTING_H